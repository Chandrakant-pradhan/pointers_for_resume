import numpy as np
import pickle as pkl

class LDA:
    def __init__(self,k):
        self.n_components = k
        self.linear_discriminants = None

    def fit(self, X, y):
        """
        X: (n,d,d) array consisting of input features
        y: (n,) array consisting of labels
        return: Linear Discriminant np.array of size (d*d,k)
        """
        # TODO
        k = self.n_components
        self.linear_discriminants=np.zeros((len(X[0]*len(X[0])),k)) # Modify as required 
        classes = np.unique(y)
        means = np.mean(X,axis=0)
        sw = np.zeros((X.shape[1]*X.shape[1]))
        for i in classes:
            selected = X[y == i]
            mean_selected = np.mean(selected, axis=0)
            sw += np.matmul(np.transpose(selected - mean_selected),(selected - mean_selected))
        
        sb = np.zeros((X.shape[1]*X.shape[1]))
        for i in classes:
            selected = X[y == i]
            mean_selected = np.mean(selected, axis=0)
            mean_diff = (mean_selected - means)
            mean_diff.reshape(-1,1)
            sb += len(selected) * np.matmul(mean_diff , np.transpose(mean_diff))
        
        eig_values, eig_vectors = np.linalg.eig(np.linalg.pinv(sw).dot(sb))
        indices = np.argsort(eig_values)[::-1]
        indices = indices[0:k]
        self.linear_discriminants = eig_vectors[:,indices]
        return(self.linear_discriminants)                 # Modify as required
        #END TODO 
    
    def transform(self, X, w):
        """
        w:Linear Discriminant array of size (d*d,1)
        return: np-array of the projected features of size (n,k)
        """
        # TODO
        projected=np.zeros((len(X),self.n_components))     # Modify as required
        X = X.reshape(X.shape[0], -1)
        projected = X@w
        return projected                   # Modify as required
        # END TODO

# if __name__ == '__main__':
#     mnist_data = 'mnist.pkl'
#     with open(mnist_data, 'rb') as f:
#         data = pkl.load(f)
#     X=data[0]
#     y=data[1]
#     k=10
#     lda = LDA(k)
#     w=lda.fit(X, y)
#     X_lda = lda.transform(X,w)
