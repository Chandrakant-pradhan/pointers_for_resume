#include <unordered_map>
#include <vector>
#include <iostream>
#include <utility>
#include <queue>
using namespace std;

class Graph {
public:
    int v;
    vector<vector<pair<int, int>>> adj;

    Graph(int no_of_vertices, vector<pair<int, int>> edges) {
        v = no_of_vertices;
        adj.resize(v);
        for (auto i : edges) {
            int a = i.first;
            int b = i.second;
            adj[a].push_back({b,1});
            adj[b].push_back({a,1});
        }
    }

    void bfs(int source, unordered_map<int, int>& parent) {
        vector<bool> visited(v, false);
        queue<int> q;
        q.push(source);
        parent[source] = -1;
        visited[source] = true; 
        while (!q.empty()) {
            int k = q.front();
            q.pop();
            for (auto a : adj[k]) {
                if (!visited[a.first]) {
                    visited[a.first] = true;
                    parent[a.first] = k;
                    q.push(a.first); 
                }
            }
        }
    }
};

void bfs(Graph g, int source, unordered_map<int, int>& parent) {
    g.bfs(source, parent);
}
