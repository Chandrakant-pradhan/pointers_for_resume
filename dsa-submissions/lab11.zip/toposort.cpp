#include "graph.h" // needed

// you may or may not use this dfs function
// but the end result has to be stored in stack Graph::S


void Graph::dfs(int s) {
    nodes[s]->visited = true;
    for(auto i : nodes[s]->adj){
        int a = i.first;
        int b = i.second;
        if(!nodes[a]->visited){
            nodes[a]->visited = true;
            dfs(a);
        }
    }
    S.push(s);
}

// this function is to be implemented
void Graph::topoSort() {
    resetVisit();
    dfs(0);
    print();
}
